import math
import random
from string import ascii_lowercase, ascii_uppercase

from sympy import *
from sympy import latex

x,y,z = symbols('x y z')
def template(option_difficulty, option_random, style="raw"):  # style = ‘latex’
    symbols = []
    variable_num = 1
    number_of_expressions = 2
    expressions = [' + ', ' - ', ' \times ', ' \div ']  # MULT BRINGS THE PARATHESIS
    list_temp = []
    num_coefficients = []
    problemset = ""
    if option_difficulty == "easy": # binomials with same variables
        variable_num = 1
        number_of_expressions = 2
        for i in range(number_of_expressions - 1):
            list_temp.append(random.choice(expressions))

    elif option_difficulty == "medium": #9 + 5r − 9r || 4b + 6 − 4
        variable_num = random.randint(1, 2)
        number_of_expressions = random.randint(variable_num + 1, 3)
        for i in range(number_of_expressions - 1):
            list_temp.append(random.choice(expressions))

    elif option_difficulty == "hard": #10x + 36 − 38x − 47 ||  −4p − (1 − 6 p) || −8(−5b + 7) + 5b
        variable_num = random.randint(2, 3)
        number_of_expressions = random.randint(3, 4)
        for i in range(number_of_expressions - 1):
            list_temp.append(random.choice(expressions))
    
    num_coefficients = coefficients(number_of_expressions)
    print(num_coefficients)
    print("expressions", list_temp)
    symbols = variables(variable_num)
    print(symbols)
    problemset = []
    problemset = '{} {} {}'.format(str(num_coefficients[0]) + str(symbols[0]), ''.join(list_temp), str(num_coefficients[1]) + str(symbols[0]))
    print("problem", problemset)

    if style == "latex":
        return(latex(problemset))
    else:
        return(problemset, 2)

def coefficients(num_coeff = 1):
    coeff = []
    number = 0
    for i in range(num_coeff):
        number = random.randint(2,10)
        if random.randint(1,2) == 1:
            number = number * -1
        coeff.append(number)
    return(coeff)


def variables(number_of_variables=1):
    variables = []  # local storage of variables
    result = list(ascii_lowercase + ascii_uppercase)
    result.remove("l")
    result.remove("o")
    result.remove("O")
    result.remove("I")
    result.remove("i")
    for i in range(number_of_variables):
        variables.append(random.choice(result))
    return(variables)
#simplify((x**3 + x**2 - x - 1)/(x**2 + 2*x + 1))

a, b = template("easy", False)
print(a, b)
a, b = template("medium", False)
print(a, b)
a, b = template("hard", False)
print(a, b)